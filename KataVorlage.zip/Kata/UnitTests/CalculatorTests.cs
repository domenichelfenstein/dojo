﻿namespace Kata.App
{
    using FluentAssertions;
    using Xunit;

    public class CalculatorTests
    {
        private readonly Calculator testee;

        public CalculatorTests()
        {
            this.testee = new Calculator();
        }

        [Fact]
        public void ReturnsSum_OnAdd()
        {
            // Arrange
            var a = 15;
            var b = 20;
            var expectedResult = 35;

            // Act
            var result = this.testee.Add(
                a,
                b);

            // Assert
            Assert.Equal(expectedResult, result);
        }

        [Fact]
        public void SameTest_ButWithFluentAssertion()
        {
            // Arrange
            var a = 15;
            var b = 20;
            var expectedResult = 35;

            // Act
            var result = this.testee.Add(
                a,
                b);

            // Assert
            result.Should().Be(expectedResult);
        }
    }
}