﻿namespace Kata.App
{
    // ToDo: Implement Class
    public class InputHandler
    {
        public InputHandler(
            Calculator calculator)
        {
        }

        public void Input(
            int i)
        {
        }

        public void Plus()
        {
        }

        public int Calculate()
        {
            return 0;
        }
    }
}