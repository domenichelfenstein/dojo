﻿namespace Kata.App
{
    public class Calculator
    {
        public int Add(
            int a,
            int b)
        {
            // ToDo: Implement
            return 0;
        }
    }
}