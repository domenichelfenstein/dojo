﻿namespace Kata.App
{
    using FluentAssertions;
    using Xbehave;

    public class CalculatorSpecifications
    {
        private InputHandler testee;

        [Background]
        public void Background()
        {
            this.testee = new InputHandler(
                new Calculator());
        }

        [Scenario]
        public void ResultatÜberEingabeBerechnen(
            int result)
        {
            "es wird 15 eingegeben".x(()
                => this.testee.Input(15));

            "es wird `Plus` geklickt".x(()
                => this.testee.Plus());

            "es wird 20 eingegeben".x(()
                => this.testee.Input(20));

            "wenn `=` geklickt wird".x(()
                => result = this.testee.Calculate());

            "soll das Resultat 35 lauten".x(()
                => result.Should().Be(35));
        }
    }
}